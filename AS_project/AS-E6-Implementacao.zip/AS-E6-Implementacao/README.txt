GRUPO 405 - FARMLINK
João Afonso Ferreira (103037) 
João Pedro Ferreira (103625)
Luís Couto (89078)
Rafael Curado (103199)

REPOSITORIO USADO -> https://github.com/joaoafonso02/AS

COMO TESTAR:
- aceder: https://farmlink2022.herokuapp.com/

- registe uma conta com as credenciais que desejar 

       			OU USE

  email: farmlink@gmail.com
  passw: 123456

- navegue pela aplicação e teste